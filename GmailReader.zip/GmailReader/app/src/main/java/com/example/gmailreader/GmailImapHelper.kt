package com.example.gmailreader

import android.text.Html
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Properties
import javax.mail.FetchProfile
import javax.mail.Folder
import javax.mail.Message
import javax.mail.Multipart
import javax.mail.Part
import javax.mail.Session
import javax.mail.internet.InternetAddress

object GmailImapHelper {

    private val keywordOtp = Regex(
        "(?i)(?:code|otp|verification|verify|pin|passcode|رمز|كود)[^0-9]{0,40}(?<!\\d)(\\d{4,8})(?!\\d)"
    )
    private val plainOtp = Regex("(?<!\\d)(\\d{4,8})(?!\\d)")

    fun extractOtp(subject: String, body: String): String? {
        val text = subject + "\n" + body.take(3000)
        keywordOtp.find(text)?.let { return it.groupValues[1] }
        return plainOtp.find(subject)?.value ?: plainOtp.find(body.take(3000))?.value
    }

    suspend fun fetchInbox(account: Account, limit: Int = 15): List<EmailMessage> =
        withContext(Dispatchers.IO) {
            val props = Properties().apply {
                put("mail.store.protocol", "imaps")
                put("mail.imaps.host", "imap.gmail.com")
                put("mail.imaps.port", "993")
                put("mail.imaps.ssl.enable", "true")
                put("mail.imaps.connectiontimeout", "15000")
                put("mail.imaps.timeout", "20000")
            }
            val store = Session.getInstance(props).getStore("imaps")
            try {
                store.connect("imap.gmail.com", 993, account.email, account.password)
                val folder = store.getFolder("INBOX")
                folder.open(Folder.READ_ONLY)
                val total = folder.messageCount
                if (total == 0) {
                    folder.close(false)
                    return@withContext emptyList()
                }
                val start = maxOf(1, total - limit + 1)
                val msgs = folder.getMessages(start, total)
                val fp = FetchProfile().apply {
                    add(FetchProfile.Item.ENVELOPE)
                    add(FetchProfile.Item.CONTENT_INFO)
                }
                folder.fetch(msgs, fp)
                val result = msgs.reversed().map { toModel(account.email, it) }
                folder.close(false)
                result
            } finally {
                try { store.close() } catch (_: Exception) {}
            }
        }

    private fun toModel(accountEmail: String, msg: Message): EmailMessage {
        val addr = msg.from?.firstOrNull() as? InternetAddress
        val from = addr?.personal?.takeIf { it.isNotBlank() } ?: addr?.address ?: "Unknown"
        val subject = msg.subject ?: "(بدون عنوان)"
        val date = (msg.sentDate ?: msg.receivedDate)?.time ?: 0L
        val body = extractText(msg).trim()
        return EmailMessage(
            id = "$accountEmail#${msg.messageNumber}",
            account = accountEmail,
            from = from,
            subject = subject,
            dateMillis = date,
            body = body,
            otp = extractOtp(subject, body)
        )
    }

    private fun extractText(part: Part): String {
        return try {
            when {
                part.isMimeType("text/plain") -> part.content.toString()
                part.isMimeType("text/html") -> htmlToText(part.content.toString())
                part.isMimeType("multipart/*") -> {
                    val mp = part.content as Multipart
                    var plain: String? = null
                    var html: String? = null
                    for (i in 0 until mp.count) {
                        val bp = mp.getBodyPart(i)
                        if (Part.ATTACHMENT.equals(bp.disposition, ignoreCase = true)) continue
                        if (bp.isMimeType("text/plain") && plain == null) {
                            plain = bp.content.toString()
                        } else if (bp.isMimeType("text/html") && html == null) {
                            html = htmlToText(bp.content.toString())
                        } else if (bp.isMimeType("multipart/*")) {
                            val t = extractText(bp)
                            if (t.isNotBlank() && plain == null) plain = t
                        }
                    }
                    plain?.takeIf { it.isNotBlank() } ?: html ?: ""
                }
                else -> ""
            }
        } catch (e: Exception) {
            ""
        }
    }

    private fun htmlToText(html: String): String {
        val cleaned = html
            .replace(Regex("(?is)<(style|script|head)[^>]*>.*?</\\1>"), "")
            .replace(Regex("(?i)<br\\s*/?>"), "\n")
            .replace(Regex("(?i)</(p|div|tr|h[1-6]|li)>"), "\n")
        return Html.fromHtml(cleaned, Html.FROM_HTML_MODE_LEGACY).toString()
            .replace('\uFFFC', ' ')
            .replace(Regex("[ \\t]+"), " ")
            .replace(Regex("\\n\\s*\\n+"), "\n\n")
            .trim()
    }
}
