package com.example.gmailreader

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class AccountStorage(context: Context) {
    private val prefs = context.getSharedPreferences("accounts_prefs", Context.MODE_PRIVATE)
    private val gson = Gson()
    private val type = object : TypeToken<List<Account>>() {}.type

    fun load(): List<Account> = try {
        val json = prefs.getString("accounts", null)
        if (json.isNullOrBlank()) emptyList() else gson.fromJson<List<Account>>(json, type) ?: emptyList()
    } catch (e: Exception) {
        emptyList()
    }

    fun save(list: List<Account>) {
        prefs.edit().putString("accounts", gson.toJson(list)).apply()
    }
}
