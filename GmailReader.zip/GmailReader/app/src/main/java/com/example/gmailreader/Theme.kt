package com.example.gmailreader

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightScheme = lightColorScheme(
    primary = Color(0xFF3949AB),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE0E4FF),
    onPrimaryContainer = Color(0xFF0A1666),
    secondary = Color(0xFF00897B),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFD0F2EC),
    onSecondaryContainer = Color(0xFF00201B),
    background = Color(0xFFF4F5FA),
    onBackground = Color(0xFF1A1C25),
    surface = Color.White,
    onSurface = Color(0xFF1A1C25),
    surfaceVariant = Color(0xFFE8EAF3),
    onSurfaceVariant = Color(0xFF515669),
    outline = Color(0xFF8A8FA3),
    outlineVariant = Color(0xFFD5D8E5),
    errorContainer = Color(0xFFFFDAD6),
    onErrorContainer = Color(0xFF410002)
)

private val DarkScheme = darkColorScheme(
    primary = Color(0xFFB5BEFF),
    onPrimary = Color(0xFF18227A),
    primaryContainer = Color(0xFF2F3A94),
    onPrimaryContainer = Color(0xFFE0E4FF),
    secondary = Color(0xFF6FD9C9),
    onSecondary = Color(0xFF00382F),
    secondaryContainer = Color(0xFF00504A),
    onSecondaryContainer = Color(0xFFB2F0E8),
    background = Color(0xFF10121A),
    onBackground = Color(0xFFE3E5F0),
    surface = Color(0xFF1A1D29),
    onSurface = Color(0xFFE3E5F0),
    surfaceVariant = Color(0xFF2A2E3D),
    onSurfaceVariant = Color(0xFFC0C4D8),
    outline = Color(0xFF8A8FA3),
    outlineVariant = Color(0xFF3A3F52),
    errorContainer = Color(0xFF93000A),
    onErrorContainer = Color(0xFFFFDAD6)
)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkScheme else LightScheme,
        content = content
    )
}
