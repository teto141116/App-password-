package com.example.gmailreader

data class Account(val email: String, val password: String)

data class EmailMessage(
    val id: String,
    val account: String,
    val from: String,
    val subject: String,
    val dateMillis: Long,
    val body: String,
    val otp: String?
) {
    val preview: String
        get() = body.lines().map { it.trim() }.filter { it.isNotEmpty() }.take(2).joinToString("\n")
}

data class UiState(
    val accounts: List<Account> = emptyList(),
    val selected: String? = null, // null = كل الحسابات
    val emails: List<EmailMessage> = emptyList(),
    val loading: Boolean = false,
    val error: String? = null,
    val opened: EmailMessage? = null,
    val message: String? = null
)
