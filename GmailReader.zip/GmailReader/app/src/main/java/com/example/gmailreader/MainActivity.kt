package com.example.gmailreader

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val dark = androidx.compose.foundation.isSystemInDarkTheme()
            val ctx = LocalContext.current
            val scheme = when {
                Build.VERSION.SDK_INT >= 31 ->
                    if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
                dark -> darkColorScheme()
                else -> lightColorScheme()
            }
            MaterialTheme(colorScheme = scheme) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    GmailApp(vm)
                }
            }
        }
    }
}

private fun copyToClipboard(ctx: Context, label: String, text: String, toast: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText(label, text))
    Toast.makeText(ctx, toast, Toast.LENGTH_SHORT).show()
}

private fun formatDate(ms: Long): String =
    if (ms == 0L) "" else SimpleDateFormat("d MMM, HH:mm", Locale.getDefault()).format(Date(ms))

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun GmailApp(vm: MainViewModel) {
    val s by vm.state.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    var showAdd by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<String?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importFromUri(uri)
    }

    LaunchedEffect(s.message) {
        s.message?.let {
            Toast.makeText(ctx, it, Toast.LENGTH_SHORT).show()
            vm.consumeMessage()
        }
    }

    val opened = s.opened
    if (opened != null) {
        BackHandler { vm.open(null) }
        DetailScreen(opened, onBack = { vm.open(null) })
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Gmail Reader") },
                actions = {
                    if (s.loading) {
                        CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp)
                    } else {
                        TextButton(onClick = { vm.refresh() }) { Text("تحديث") }
                    }
                    TextButton(onClick = { picker.launch(arrayOf("text/plain")) }) { Text("استيراد") }
                    TextButton(onClick = { showAdd = true }) { Text("إضافة") }
                }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (s.accounts.isEmpty()) {
                Box0("لا توجد حسابات. استورد ملف .txt بصيغة email:app_password أو أضف حساباً يدوياً.")
            } else {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        AccountChip("كل الحسابات", s.selected == null, onClick = { vm.select(null) })
                    }
                    items(s.accounts, key = { it.email }) { acc ->
                        AccountChip(
                            acc.email, s.selected == acc.email,
                            onClick = { vm.select(acc.email) },
                            onLongClick = { toDelete = acc.email }
                        )
                    }
                }
                s.error?.let {
                    Text(
                        "خطأ: $it", color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                if (s.emails.isEmpty() && !s.loading) {
                    Box0("لا توجد رسائل")
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(s.emails, key = { it.id }) { m ->
                            EmailCard(m, showAccount = s.selected == null,
                                onClick = { vm.open(m) },
                                onCopyOtp = { code -> copyToClipboard(ctx, "OTP", code, "تم نسخ الكود: $code") })
                        }
                    }
                }
            }
        }
    }

    if (showAdd) {
        var email by remember { mutableStateOf("") }
        var pass by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("إضافة حساب") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(email, { email = it }, label = { Text("Email") }, singleLine = true)
                    OutlinedTextField(
                        pass, { pass = it }, label = { Text("App Password") }, singleLine = true,
                        visualTransformation = PasswordVisualTransformation()
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { vm.addAccount(email, pass); showAdd = false }) { Text("حفظ") }
            },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("إلغاء") } }
        )
    }

    toDelete?.let { email ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("حذف الحساب") },
            text = { Text(email) },
            confirmButton = {
                TextButton(onClick = { vm.removeAccount(email); toDelete = null }) { Text("حذف") }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("إلغاء") } }
        )
    }
}

@Composable
private fun Box0(text: String) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text, style = MaterialTheme.typography.bodyLarge)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AccountChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null
) {
    val container = if (selected) MaterialTheme.colorScheme.primaryContainer
    else MaterialTheme.colorScheme.surfaceVariant
    Surface(
        shape = RoundedCornerShape(50),
        color = container,
        modifier = Modifier.clip(RoundedCornerShape(50))
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
    ) {
        Text(
            label, maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            style = MaterialTheme.typography.labelLarge
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EmailCard(
    m: EmailMessage,
    showAccount: Boolean,
    onClick: () -> Unit,
    onCopyOtp: (String) -> Unit
) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(
                    m.from, fontWeight = FontWeight.Bold, maxLines = 1,
                    overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                )
                Text(formatDate(m.dateMillis), style = MaterialTheme.typography.labelSmall)
            }
            Spacer(Modifier.height(4.dp))
            Text(m.subject, maxLines = 1, overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.titleSmall)
            if (m.preview.isNotEmpty()) {
                Spacer(Modifier.height(4.dp))
                Text(
                    m.preview, maxLines = 2, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (showAccount) {
                Spacer(Modifier.height(4.dp))
                Text(m.account, style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary)
            }
            m.otp?.let { code ->
                Spacer(Modifier.height(8.dp))
                Button(onClick = { onCopyOtp(code) }, modifier = Modifier.fillMaxWidth()) {
                    Text("نسخ الكود: $code")
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DetailScreen(m: EmailMessage, onBack: () -> Unit) {
    val ctx = LocalContext.current
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("الرسالة", maxLines = 1) },
                navigationIcon = { TextButton(onClick = onBack) { Text("رجوع") } },
                actions = {
                    TextButton(onClick = {
                        copyToClipboard(ctx, "Email", m.body, "تم نسخ النص")
                    }) { Text("نسخ الكل") }
                }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState())) {
            Text(m.subject, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text("من: ${m.from}", style = MaterialTheme.typography.bodyMedium)
            Text("إلى: ${m.account}", style = MaterialTheme.typography.bodySmall)
            Text(formatDate(m.dateMillis), style = MaterialTheme.typography.bodySmall)
            m.otp?.let { code ->
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = { copyToClipboard(ctx, "OTP", code, "تم نسخ الكود: $code") },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("نسخ الكود: $code") }
            }
            Spacer(Modifier.height(16.dp))
            SelectionContainer {
                Text(
                    m.body.ifEmpty { "(لا يوجد محتوى نصي)" },
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}
