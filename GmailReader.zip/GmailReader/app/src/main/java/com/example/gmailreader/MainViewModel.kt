package com.example.gmailreader

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val storage = AccountStorage(app)
    private val _state = MutableStateFlow(UiState(accounts = storage.load()))
    val state: StateFlow<UiState> = _state.asStateFlow()

    private val cache = HashMap<String, List<EmailMessage>>()
    private var job: Job? = null

    init {
        if (_state.value.accounts.isNotEmpty()) load()
    }

    fun select(email: String?) {
        _state.update { it.copy(selected = email, error = null) }
        showCached()
        load()
    }

    fun refresh() = load()

    fun open(msg: EmailMessage?) = _state.update { it.copy(opened = msg) }

    fun consumeMessage() = _state.update { it.copy(message = null) }

    fun addAccount(email: String, password: String) {
        val e = email.trim()
        val p = password.filter { !it.isWhitespace() }
        if (e.isEmpty() || p.isEmpty() || !e.contains("@")) {
            _state.update { it.copy(message = "بيانات غير صحيحة") }
            return
        }
        val current = _state.value.accounts
        if (current.any { it.email.equals(e, true) }) {
            _state.update { it.copy(message = "الحساب موجود مسبقاً") }
            return
        }
        val list = current + Account(e, p)
        storage.save(list)
        _state.update { it.copy(accounts = list, message = "تمت إضافة الحساب") }
    }

    fun removeAccount(email: String) {
        val list = _state.value.accounts.filterNot { it.email == email }
        storage.save(list)
        cache.remove(email)
        val sel = if (_state.value.selected == email) null else _state.value.selected
        _state.update { it.copy(accounts = list, selected = sel, message = "تم حذف الحساب") }
        showCached()
        if (list.isNotEmpty()) load() else _state.update { it.copy(emails = emptyList()) }
    }

    fun importFromUri(uri: Uri) {
        viewModelScope.launch {
            try {
                val lines = withContext(Dispatchers.IO) {
                    getApplication<Application>().contentResolver.openInputStream(uri)
                        ?.bufferedReader()?.use { it.readLines() } ?: emptyList()
                }
                val current = _state.value.accounts.toMutableList()
                var added = 0
                for (raw in lines) {
                    val line = raw.trim().removePrefix("\uFEFF")
                    val idx = line.indexOf(':')
                    if (idx <= 0) continue
                    val email = line.substring(0, idx).trim()
                    val pass = line.substring(idx + 1).filter { !it.isWhitespace() }
                    if (!email.contains("@") || pass.isEmpty()) continue
                    if (current.any { it.email.equals(email, true) }) continue
                    current.add(Account(email, pass))
                    added++
                }
                storage.save(current)
                _state.update { it.copy(accounts = current, message = "تم استيراد $added حساب") }
                if (added > 0) load()
            } catch (e: Exception) {
                _state.update { it.copy(message = "فشل قراءة الملف: ${e.message}") }
            }
        }
    }

    private fun showCached() {
        val s = _state.value
        val list = if (s.selected == null) {
            cache.values.flatten().sortedByDescending { it.dateMillis }.take(40)
        } else {
            cache[s.selected] ?: emptyList()
        }
        _state.update { it.copy(emails = list) }
    }

    private fun load() {
        job?.cancel()
        val s = _state.value
        val targets = if (s.selected == null) s.accounts else s.accounts.filter { it.email == s.selected }
        if (targets.isEmpty()) {
            _state.update { it.copy(emails = emptyList(), loading = false) }
            return
        }
        job = viewModelScope.launch {
            _state.update { it.copy(loading = true, error = null) }
            val semaphore = Semaphore(4)
            val errors = mutableListOf<String>()
            val results = targets.map { acc ->
                async {
                    semaphore.withPermit {
                        try {
                            acc.email to GmailImapHelper.fetchInbox(acc, 15)
                        } catch (e: Exception) {
                            synchronized(errors) { errors.add("${acc.email}: ${e.message ?: "خطأ"}") }
                            acc.email to null
                        }
                    }
                }
            }.awaitAll()
            results.forEach { (email, list) -> if (list != null) cache[email] = list }
            val merged = results.mapNotNull { it.second }.flatten().sortedByDescending { it.dateMillis }
            val finalList = if (s.selected == null) merged.take(40) else merged
            _state.update {
                it.copy(
                    emails = if (finalList.isEmpty() && errors.isNotEmpty()) it.emails else finalList,
                    loading = false,
                    error = errors.firstOrNull()
                )
            }
        }
    }
}
