package com.example.gmailreader

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap
import javax.mail.AuthenticationFailedException

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val storage = AccountStorage(app)
    private val initialAccounts = storage.load()
    private val _state = MutableStateFlow(
        UiState(accounts = initialAccounts, selected = initialAccounts.firstOrNull()?.email)
    )
    val state: StateFlow<UiState> = _state.asStateFlow()

    private val cache = ConcurrentHashMap<String, List<EmailMessage>>()
    private var job: Job? = null
    private var loadId = 0

    init {
        if (initialAccounts.isNotEmpty()) load()
    }

    fun select(email: String?) {
        _state.update { it.copy(selected = email, error = null) }
        publish()
        load()
    }

    fun refresh() = load()
    fun open(msg: EmailMessage?) = _state.update { it.copy(opened = msg) }
    fun consumeMessage() = _state.update { it.copy(message = null) }

    fun addAccount(email: String, password: String) {
        val e = email.trim()
        val p = password.filter { !it.isWhitespace() }
        if (e.isEmpty() || p.isEmpty() || !e.contains("@")) {
            _state.update { it.copy(message = "بيانات غير صحيحة") }
            return
        }
        val current = _state.value.accounts
        if (current.any { it.email.equals(e, true) }) {
            _state.update { it.copy(message = "الحساب موجود مسبقاً") }
            return
        }
        val list = current + Account(e, p)
        storage.save(list)
        _state.update { it.copy(accounts = list, selected = e, error = null, message = "تمت إضافة الحساب") }
        publish()
        load()
    }

    fun removeAccount(email: String) {
        val list = _state.value.accounts.filterNot { it.email == email }
        storage.save(list)
        cache.remove(email)
        val sel = if (_state.value.selected == email) list.firstOrNull()?.email else _state.value.selected
        _state.update { it.copy(accounts = list, selected = sel, message = "تم حذف الحساب") }
        publish()
        load()
    }

    fun importFromUri(uri: Uri) {
        viewModelScope.launch {
            try {
                val lines = withContext(Dispatchers.IO) {
                    getApplication<Application>().contentResolver.openInputStream(uri)
                        ?.bufferedReader()?.use { it.readLines() } ?: emptyList()
                }
                val current = _state.value.accounts.toMutableList()
                var firstAdded: String? = null
                var added = 0
                for (raw in lines) {
                    val line = raw.trim().removePrefix("\uFEFF")
                    val idx = line.indexOf(':')
                    if (idx <= 0) continue
                    val email = line.substring(0, idx).trim()
                    val pass = line.substring(idx + 1).filter { !it.isWhitespace() }
                    if (!email.contains("@") || pass.isEmpty()) continue
                    if (current.any { it.email.equals(email, true) }) continue
                    current.add(Account(email, pass))
                    if (firstAdded == null) firstAdded = email
                    added++
                }
                storage.save(current)
                _state.update {
                    it.copy(
                        accounts = current,
                        selected = firstAdded ?: it.selected,
                        message = "تم استيراد $added حساب"
                    )
                }
                publish()
                if (added > 0) load()
            } catch (e: Exception) {
                _state.update { it.copy(message = "فشل قراءة الملف: ${e.message}") }
            }
        }
    }

    private fun publish() {
        _state.update { s ->
            val list = if (s.selected == null) {
                val keys = s.accounts.map { it.email }.toSet()
                cache.filterKeys { it in keys }.values.flatten()
                    .sortedByDescending { it.dateMillis }.take(40)
            } else {
                cache[s.selected] ?: emptyList()
            }
            s.copy(emails = list)
        }
    }

    private fun friendly(acc: String, e: Exception): String = when (e) {
        is AuthenticationFailedException ->
            "$acc: فشل تسجيل الدخول — تأكد من App Password وتفعيل IMAP"
        else -> "$acc: ${e.message ?: "خطأ في الاتصال"}"
    }

    private fun load() {
        job?.cancel()
        val s = _state.value
        val targets = if (s.selected == null) s.accounts else s.accounts.filter { it.email == s.selected }
        if (targets.isEmpty()) {
            _state.update { it.copy(loading = false) }
            return
        }
        val id = ++loadId
        val limit = if (s.selected == null) 8 else 15
        job = viewModelScope.launch {
            _state.update { it.copy(loading = true, error = null) }
            val semaphore = Semaphore(5)
            val errors = mutableListOf<String>()
            targets.map { acc ->
                async {
                    semaphore.withPermit {
                        try {
                            GmailImapHelper.fetchInbox(acc, limit) { list ->
                                cache[acc.email] = list
                                if (id == loadId) publish()
                            }
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            synchronized(errors) { errors.add(friendly(acc.email, e)) }
                        }
                    }
                }
            }.awaitAll()
            if (id == loadId) {
                _state.update { it.copy(loading = false, error = errors.firstOrNull()) }
            }
        }
    }
}
